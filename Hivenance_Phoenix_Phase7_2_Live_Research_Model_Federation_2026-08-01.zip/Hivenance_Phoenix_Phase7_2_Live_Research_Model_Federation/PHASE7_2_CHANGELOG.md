# Phase 7.2 Changelog

## Added

- Live research model federation inside the Phase-2 truth-settled competition.
- Six dependency-light federated research models covering Freqtrade, Jesse, FreqAI, FinRL Crypto, MacroHFT, and WebCryptoAgent-inspired research patterns.
- Per-model fidelity, implementation, runtime, training-mode, and authority descriptors.
- Horizon-aware expected-movement scaling for all federated models.
- Research Federation dashboard panel.
- `scripts/run_phase7_2_federation.py` convenience runner.
- `scripts/phase7_2_preflight.py` safety and fidelity preflight.
- `scripts/phase7_2_synthetic_soak.py` multi-regime federation campaign.
- Six new automated tests.
- `research_model_federation` in the Phoenix authority map.

## Changed

- Phase-2 competition now evaluates 12 models per symbol across three horizons, producing 36 forecasts per eligible observation snapshot.
- Hypothesis run records now identify native, federated, and baseline rosters.
- The scorecard now distinguishes `PRIMARY`, `FEDERATED`, and `BASELINE` roles.
- The scorecard reports a research-only champion separately from the all-model result.
- Phase-2 payloads now expose a machine-readable federation manifest.
- Phoenix authority-map version advanced to `phase7.2-authority-v1`.

## Preserved

- Phase 1 remains model-agnostic and public-data only.
- Existing SQLite evidence is backward-compatible.
- No private API, credential, wallet, or order path was added.
- All models remain `execution_eligible=false`.
- Phase 6 and Phase 7 retain sole live and scaling authority.

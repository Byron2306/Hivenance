"""Hivenance strategy research packages."""

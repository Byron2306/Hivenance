#!/usr/bin/env python3
"""Convenience entry point for the Phase-7.2 live research federation.

This launches the ordinary public Phase-1 observer plus the Phase-2 truth-settled
model competition. It has no private exchange or order-submission interface.
"""
from __future__ import annotations

from run_phase2_hypotheses import main


if __name__ == "__main__":
    raise SystemExit(main())

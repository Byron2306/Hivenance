from __future__ import annotations

from dataclasses import asdict
from typing import Any, Iterable

from .cost_model import ResearchCostModel
from .hypothesis_models import (
    BreakoutContinuationModel,
    DeterministicRandomBaseline,
    ExhaustionMeanReversionModel,
    NoTradeBaseline,
    SimpleMeanReversionBaseline,
    SimpleMomentumBaseline,
)
from .models import FeatureVector, Forecast
from .research_model_federation import ResearchModelFederation


class HypothesisCompetition:
    """Runs frozen Phase-2 hypotheses and baselines on the same feature vector."""

    def __init__(self, cfg: Any) -> None:
        cost_model = ResearchCostModel(
            taker_fee_bps_per_side=float(getattr(cfg, "phase2_taker_fee_bps_per_side", 10.0) or 10.0),
            reference_notional_usd=float(getattr(cfg, "phase2_reference_notional_usd", 5.0) or 5.0),
            latency_buffer_bps=float(getattr(cfg, "phase2_latency_buffer_bps", 2.0) or 2.0),
            safety_buffer_bps=float(getattr(cfg, "phase2_safety_buffer_bps", 3.0) or 3.0),
            max_total_cost_bps=float(getattr(cfg, "phase2_max_total_cost_bps", 150.0) or 150.0),
        )
        min_quality = float(getattr(cfg, "phase2_min_data_quality", 0.99) or 0.99)
        edge_multiple = float(getattr(cfg, "phase2_minimum_edge_multiple", 2.0) or 2.0)
        self.primary_models = (
            BreakoutContinuationModel(
                cost_model,
                min_data_quality=min_quality,
                min_expansion=float(getattr(cfg, "phase2_breakout_min_expansion", 1.25) or 1.25),
                min_volume_zscore=float(getattr(cfg, "phase2_breakout_min_volume_zscore", 0.50) or 0.50),
                min_return_zscore=float(getattr(cfg, "phase2_breakout_min_return_zscore", 0.75) or 0.75),
                minimum_edge_multiple=edge_multiple,
            ),
            ExhaustionMeanReversionModel(
                cost_model,
                min_data_quality=min_quality,
                min_stretch_zscore=float(getattr(cfg, "phase2_reversion_min_stretch_zscore", 1.50) or 1.50),
                min_range_extreme=float(getattr(cfg, "phase2_reversion_min_range_extreme", 0.85) or 0.85),
                minimum_edge_multiple=edge_multiple,
            ),
        )
        self.baseline_models = (
            NoTradeBaseline(),
            SimpleMomentumBaseline(cost_model),
            SimpleMeanReversionBaseline(cost_model),
            DeterministicRandomBaseline(cost_model),
        )
        self.federation = ResearchModelFederation(cfg, cost_model)
        self.federated_models = self.federation.models

    @property
    def primary_ids(self) -> tuple[str, ...]:
        return tuple(model.model_id for model in self.primary_models)

    @property
    def baseline_ids(self) -> tuple[str, ...]:
        return tuple(model.model_id for model in self.baseline_models)

    @property
    def federated_ids(self) -> tuple[str, ...]:
        return tuple(model.model_id for model in self.federated_models)

    @property
    def all_model_ids(self) -> tuple[str, ...]:
        return (*self.primary_ids, *self.federated_ids, *self.baseline_ids)

    def federation_manifest(self) -> dict[str, Any]:
        return self.federation.manifest()

    def evaluate(self, features: FeatureVector, horizons: Iterable[int]) -> list[Forecast]:
        forecasts: list[Forecast] = []
        for horizon in horizons:
            for model in (*self.primary_models, *self.federated_models, *self.baseline_models):
                forecast = model.forecast(features, horizon_seconds=int(horizon))
                if forecast.execution_eligible:
                    raise RuntimeError(f"research model {forecast.model_id} attempted execution eligibility")
                forecasts.append(forecast)
        return forecasts

    @staticmethod
    def summarize(forecasts: Iterable[Forecast]) -> dict[str, Any]:
        rows = list(forecasts)
        return {
            "forecasts_total": len(rows),
            "non_abstain_forecasts": sum(1 for item in rows if not item.abstain),
            "abstentions": sum(1 for item in rows if item.abstain),
            "by_model": {
                model_id: {
                    "forecasts": sum(1 for item in rows if item.model_id == model_id),
                    "non_abstain": sum(1 for item in rows if item.model_id == model_id and not item.abstain),
                }
                for model_id in sorted({item.model_id for item in rows})
            },
        }

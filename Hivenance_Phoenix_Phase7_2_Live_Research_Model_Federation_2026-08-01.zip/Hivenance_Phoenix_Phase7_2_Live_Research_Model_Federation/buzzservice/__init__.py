"""BuzzService package marker."""

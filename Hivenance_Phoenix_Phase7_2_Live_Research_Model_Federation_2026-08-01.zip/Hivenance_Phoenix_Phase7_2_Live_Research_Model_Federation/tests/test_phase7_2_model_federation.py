from __future__ import annotations

import time
from dataclasses import asdict
from types import SimpleNamespace

from agents.phoenix_authority import PhoenixAuthorityGuard, PROTECTED_ACTIONS
from strategies.volatility_breakout.cost_model import ResearchCostModel
from strategies.volatility_breakout.hypothesis_competition import HypothesisCompetition
from strategies.volatility_breakout.models import FeatureVector
from strategies.volatility_breakout.research_model_federation import ResearchModelFederation


def feature(**overrides) -> FeatureVector:
    values = dict(
        symbol="TEST/USD",
        timestamp_ms=int(time.time() * 1000),
        price=100.0,
        realized_volatility_fast=0.008,
        realized_volatility_baseline=0.004,
        volatility_expansion=2.0,
        volume_zscore=2.0,
        trade_count_zscore=None,
        order_flow_imbalance=None,
        book_imbalance=0.25,
        spread_bps=4.0,
        depth_usd_25bps=1_000_000.0,
        quote_volume_24h=100_000_000.0,
        return_5=0.012,
        freshness_sec=1.0,
        continuity_ratio=1.0,
        data_quality=1.0,
        values={"feature_version": "phase2.v1"},
        complete=True,
        return_zscore=2.2,
        price_zscore=2.0,
        range_position=0.95,
        trend_slope=0.001,
        atr_pct=0.01,
        reversal_return_1=-0.003,
        momentum_consistency=0.8,
        volume_ratio=2.0,
    )
    values.update(overrides)
    return FeatureVector(**values)


def cfg(**overrides):
    values = dict(
        phase2_federation_enabled=True,
        phase2_federation_min_data_quality=0.99,
        phase2_federation_minimum_edge_multiple=1.25,
    )
    values.update(overrides)
    return SimpleNamespace(**values)


def test_federation_registers_six_live_research_models():
    federation = ResearchModelFederation(cfg(), ResearchCostModel())
    manifest = federation.manifest()
    assert manifest["enabled"] is True
    assert manifest["model_count"] == 6
    assert len(set(federation.model_ids)) == 6
    assert manifest["execution_wired"] is False
    assert manifest["orders_submitted"] == 0
    assert all(item["execution_eligible"] is False for item in manifest["models"])
    assert all(item["authority"] == "research_forecast_only" for item in manifest["models"])


def test_federated_models_emit_same_non_executable_contract():
    federation = ResearchModelFederation(cfg(), ResearchCostModel())
    rows = [model.forecast(feature(), horizon_seconds=900) for model in federation.models]
    assert len(rows) == 6
    assert all(row.execution_eligible is False for row in rows)
    assert all(row.model_id in federation.model_ids for row in rows)
    assert all(row.feature_version == "phase7.2.federation.v1" for row in rows)
    assert all((row.inputs.get("federation") or {}).get("authority") == "research_forecast_only" for row in rows)


def test_horizon_estimates_are_not_cloned_across_5m_15m_60m():
    federation = ResearchModelFederation(cfg(), ResearchCostModel())
    model = next(item for item in federation.models if item.model_id == "candidate_freqai_transparent_linear_v1")
    rows = [model.forecast(feature(), horizon_seconds=h) for h in (300, 900, 3600)]
    assert all(row.abstain is False for row in rows)
    moves = [row.expected_move_bps for row in rows]
    assert moves[0] < moves[1] < moves[2]


def test_low_quality_or_missing_features_force_federated_abstention():
    federation = ResearchModelFederation(cfg(), ResearchCostModel())
    bad = feature(data_quality=0.4, complete=False)
    rows = [model.forecast(bad, horizon_seconds=300) for model in federation.models]
    assert all(row.abstain is True for row in rows)
    assert all(row.execution_eligible is False for row in rows)


def test_competition_contains_native_federated_and_baseline_models():
    competition = HypothesisCompetition(cfg())
    rows = competition.evaluate(feature(), (300, 900, 3600))
    assert len(competition.primary_ids) == 2
    assert len(competition.federated_ids) == 6
    assert len(competition.baseline_ids) == 4
    assert len(rows) == 36
    assert all(row.execution_eligible is False for row in rows)


def test_federation_has_no_protected_authority():
    guard = PhoenixAuthorityGuard()
    for action in PROTECTED_ACTIONS:
        decision = guard.decision("research_model_federation", action)
        assert decision.allowed is False

from __future__ import annotations

import math
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

from agents.data_store_agent import DataStoreAgent
from strategies.volatility_breakout.candidate_selector import ObservationOnlyCandidateSelector
from strategies.volatility_breakout.feature_engine import Phase1FeatureEngine
from strategies.volatility_breakout.models import CandidateObservation
from strategies.volatility_breakout.observation_swarm import ObservationSwarmAgent


@dataclass
class FakeConfig:
    exchange: str = 'kraken'
    phase1_observation_enabled: bool = True
    phase1_observation_interval_sec: int = 120
    phase1_observation_max_symbols: int = 2
    phase1_observation_quote_assets: tuple[str, ...] = ('USD',)
    phase1_observation_include: tuple[str, ...] = ()
    phase1_observation_exclude: tuple[str, ...] = ()
    phase1_observation_timeframe: str = '1m'
    phase1_observation_lookback: int = 121
    phase1_observation_orderbook_depth: int = 50
    phase1_observation_short_window: int = 5
    phase1_observation_baseline_window: int = 60
    phase1_observation_stale_after_sec: int = 180
    phase1_observation_min_success_ratio: float = 0.9
    phase1_observation_min_listing_age_days: float = 90.0
    phase1_observation_min_quote_volume_usd: float = 5_000_000.0
    phase1_observation_min_depth_usd_25bps: float = 25_000.0
    phase1_observation_max_spread_bps: float = 35.0
    phase1_observation_min_data_quality: float = 0.99


class FakeClient:
    def __init__(self) -> None:
        self.orders = []
        now = int(time.time() * 1000)
        self._ohlcv = {}
        for index, symbol in enumerate(('BTC/USD', 'ETH/USD')):
            rows = []
            base_price = 50_000.0 if symbol.startswith('BTC') else 3_000.0
            for i in range(121):
                ts = now - (120 - i) * 60_000
                price = base_price * (1.0 + 0.0002 * i + 0.0001 * math.sin(i))
                volume = 1_000.0 + i * 5.0 + (200.0 if i >= 116 else 0.0)
                rows.append([ts, price, price * 1.001, price * 0.999, price, volume])
            self._ohlcv[symbol] = rows

    def load_markets(self):
        return {
            'BTC/USD': {'active': True, 'spot': True, 'type': 'spot'},
            'ETH/USD': {'active': True, 'spot': True, 'type': 'spot'},
            'BAD/USD': {'active': False, 'spot': True, 'type': 'spot'},
        }

    def fetch_tickers(self):
        return {
            'BTC/USD': {'last': 51_200.0, 'quoteVolume': 800_000_000.0},
            'ETH/USD': {'last': 3_070.0, 'quoteVolume': 500_000_000.0},
            'BAD/USD': {'last': 1.0, 'quoteVolume': 900_000_000.0},
        }

    def fetch_ohlcv(self, symbol, timeframe='1m', limit=121):
        return self._ohlcv[symbol][-limit:]

    def fetch_order_book(self, symbol, limit=50):
        mid = 51_200.0 if symbol.startswith('BTC') else 3_070.0
        bids = [[mid * (1 - 0.0002 * (i + 1)), 20.0] for i in range(limit)]
        asks = [[mid * (1 + 0.0002 * (i + 1)), 18.0] for i in range(limit)]
        return {'bids': bids, 'asks': asks}

    def fetch_ticker(self, symbol):
        return self.fetch_tickers()[symbol]


class CaptureCoordinator:
    def __init__(self, store: DataStoreAgent) -> None:
        self.events = []
        self.store = store

    def share_data(self, key, event):
        self.events.append((key, event))
        self.store.handle_event(event)


def test_phase1_observer_collects_and_never_executes(tmp_path: Path):
    store = DataStoreAgent(str(tmp_path / 'obs.db'))
    coordinator = CaptureCoordinator(store)
    client = FakeClient()
    observer = ObservationSwarmAgent(FakeConfig(), client, coordinator=coordinator)

    payload = observer.run_once()

    assert payload['mode'] == 'observation_only'
    assert payload['execution_wired'] is False
    assert payload['orders_submitted'] == 0
    assert len(payload['candidates']) == 2
    assert all(row['execution_eligible'] is False for row in payload['candidates'])
    assert client.orders == []
    assert any(key == 'buzz.observation.snapshot' for key, _ in coordinator.events)

    rows = store.get_observation_snapshots(limit=10)
    runs = store.get_observation_runs(limit=10)
    assert len(rows) == 2
    assert len(runs) == 1
    assert all(row['execution_eligible'] is False for row in rows)
    assert runs[0]['orders_submitted'] == 0


def test_quality_marks_stale_and_gapped_data_incomplete():
    engine = Phase1FeatureEngine(timeframe='1m', short_window=5, baseline_window=60, stale_after_sec=120)
    now = int(time.time() * 1000)
    rows = []
    for i in range(61):
        ts = now - (180 + (60 - i) * 120) * 1000
        rows.append([ts, 100, 101, 99, 100 + i * 0.01, 1000])
    features = engine.build(
        symbol='TEST/USD',
        ohlcv=rows,
        orderbook={'bids': [[100, 1000]], 'asks': [[100.1, 1000]]},
        ticker={'last': 100.05, 'quoteVolume': 20_000_000},
        observed_at_ms=now,
    )
    assert features.complete is False
    assert features.data_quality < 0.99
    assert features.freshness_sec > 120
    assert (features.continuity_ratio or 0.0) < 0.95


def test_selector_separates_observation_from_execution():
    selector = ObservationOnlyCandidateSelector(
        min_depth_usd_25bps=25_000,
        min_quote_volume_24h_usd=5_000_000,
        max_spread_bps=35,
        min_data_quality=0.99,
    )
    candidate = CandidateObservation(
        symbol='GOOD/USD', venue='kraken', timestamp_ms=1, price=10.0,
        quote_volume_24h=50_000_000, spread_bps=5.0, depth_usd_25bps=500_000,
        listing_age_days=None, venue_count=1, data_quality=1.0, freshness_sec=1.0,
        continuity_ratio=1.0, values={'volatility_expansion': 2.0},
    )
    result = selector.evaluate(candidate)
    assert result.observation_eligible is True
    assert result.execution_eligible is False


def test_unavailable_microstructure_fields_remain_none():
    engine = Phase1FeatureEngine(timeframe='1m', short_window=5, baseline_window=60)
    unavailable = engine.unavailable('NONE/USD', 1)
    assert unavailable.trade_count_zscore is None
    assert unavailable.order_flow_imbalance is None
    assert unavailable.complete is False


def test_readiness_gate_stays_closed_until_evidence_age_met(tmp_path: Path):
    store = DataStoreAgent(str(tmp_path / 'readiness.db'))
    coordinator = CaptureCoordinator(store)
    observer = ObservationSwarmAgent(FakeConfig(), FakeClient(), coordinator=coordinator)
    observer.run_once()

    readiness = store.get_observation_readiness(
        required_days=7,
        min_mean_quality=0.5,
        min_success_ratio=0.5,
    )
    assert readiness['ready_for_phase2_review'] is False
    assert readiness['execution_eligible'] is False
    assert readiness['orders_submitted'] == 0
    assert 'insufficient_observation_days' in readiness['reasons']

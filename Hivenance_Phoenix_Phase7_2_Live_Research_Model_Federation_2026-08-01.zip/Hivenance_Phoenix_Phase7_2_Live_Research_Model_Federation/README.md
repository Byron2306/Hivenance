# Hivenance Phoenix Phase 7.2: Live Research Model Federation

Phase 7.2 activates the useful heavy-integration ideas as research-only competitors inside the Phoenix Phase-2 truth-settled pipeline. Phase 1 remains a pure public-data observer. Phase 2 now evaluates two Phoenix-native models, six federated research models, and four baselines across 5m, 15m, and 60m horizons.

The federated implementations are transparent local adapters and proxies. They do not claim to launch the upstream Freqtrade, Jesse, FreqAI, FinRL, MacroHFT, or WebCryptoAgent runtimes. Every forecast is non-executable and carries explicit fidelity provenance.

```text
Phase 1 public observation
→ Phase 2 native + federated + baseline forecasts
→ identical truth settlement
→ Phase 3 execution simulation
→ Phase 4 adversarial validation
```

Validate with:

```bash
python scripts/phase7_2_preflight.py
python -m pytest -q
python scripts/phase7_2_synthetic_soak.py
```

Run the live public research federation with:

```bash
python scripts/run_phase7_2_federation.py --exchange kraken
```

See `PHASE7_2_OPERATOR_GUIDE.md`, `PHASE7_2_VALIDATION_REPORT.md`, and `PHASE7_2_CHANGELOG.md`.

# Hivenance Phoenix Phase 7.1: Integration Reconciliation

This package preserves the heavy research integrations while enforcing one authority chain. External bots, ML, execution parity, the signal marketplace, the Config Agent, and the Event Spine remain research or diagnostic systems. Phase 6 alone may submit live orders. Phase 7 alone may scale capital stages.

See `PHASE7_1_OPERATOR_GUIDE.md` and run `python scripts/phase7_1_preflight.py`.

# Hivenance Phoenix Phase 7: Controlled Growth Governor

This package contains the quarantined Hivenance pipeline through **Phase 7**.

- **Phase 1:** public-market observation and durable data-quality evidence.
- **Phase 2:** independent breakout and mean-reversion hypotheses with dumb baselines.
- **Phase 3:** deterministic execution simulation under venue, cost and infrastructure stress.
- **Phase 4:** adversarial validation with walk-forward, holdout, bootstrap, DSR and PBO-style diagnostics.
- **Phase 5:** human-approved, parameter-frozen public-market shadow flight.
- **Phase 6:** isolated, one-entry, USD 5 Kraken spot canary.
- **Phase 7:** evidence-gated, human-promoted growth stages with automatic demotion.

## Shipping state

Phase 7 ships **LOCKED**:

```text
phase7_stage_activation_enabled: false
phase6_live_submission_enabled: false
HIVENANCE_PHASE7_CONTROLLED_GROWTH: absent
HIVENANCE_PHASE6_LIVE_SUBMISSION: absent
active growth stage: CANARY / not activated
maximum packaged growth ceiling: USD 20
maximum simultaneous positions: 1
leverage: 1×
automatic promotion: false
```

## Growth doctrine

```text
Human proposal
→ cooling-off period
→ safety recheck
→ human approval
→ safety recheck
→ separate activation interlock
→ one controlled stage
→ fresh evidence block
```

Safety deterioration reverses direction immediately:

```text
UNKNOWN / incident / drawdown / rejection / slippage breach
→ automatic one-stage demotion
→ HALT
→ reconciliation
→ incident resolution
→ explicit human recovery at the lower stage
```

## Validate

```bash
for phase in 0 1 2 3 4 5 6 7; do
  python scripts/phase${phase}_preflight.py
done
python -m pytest -q
python scripts/phase7_synthetic_soak.py --json
```

## Safe inspection

```bash
python scripts/run_phase7_growth.py --status
```

The desktop **Growth Governor** is read-only. It contains no proposal, approval, activation, scaling, execution or recovery controls.

## Activation boundary

Do not create a Phase-7 proposal until the real Phase-6 database reports sufficient reconciled live evidence. Synthetic campaign artifacts validate engineering only and cannot unlock the governor.

See:

- `PHASE7_OPERATOR_GUIDE.md`
- `PHASE7_CHANGELOG.md`
- `PHASE7_VALIDATION_REPORT.md`
- `PHASE7_SYNTHETIC_GROWTH_REPORT.json`

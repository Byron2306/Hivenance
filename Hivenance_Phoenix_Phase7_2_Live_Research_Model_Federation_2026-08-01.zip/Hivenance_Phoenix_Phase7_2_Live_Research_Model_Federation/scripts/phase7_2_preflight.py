#!/usr/bin/env python3
from __future__ import annotations

import sys
import time
from pathlib import Path
from types import SimpleNamespace

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.phoenix_authority import PROTECTED_ACTIONS, PhoenixAuthorityGuard
from strategies.volatility_breakout.cost_model import ResearchCostModel
from strategies.volatility_breakout.models import FeatureVector
from strategies.volatility_breakout.research_model_federation import ResearchModelFederation


def fail(message: str) -> None:
    raise SystemExit("FAIL: " + message)


def strong_feature() -> FeatureVector:
    return FeatureVector(
        symbol="TEST/USD", timestamp_ms=int(time.time() * 1000), price=100.0,
        realized_volatility_fast=0.008, realized_volatility_baseline=0.004,
        volatility_expansion=2.0, volume_zscore=2.0, trade_count_zscore=None,
        order_flow_imbalance=None, book_imbalance=0.25, spread_bps=4.0,
        depth_usd_25bps=1_000_000.0, quote_volume_24h=100_000_000.0,
        return_5=0.012, freshness_sec=1.0, continuity_ratio=1.0,
        data_quality=1.0, values={"feature_version": "phase2.v1"}, complete=True,
        return_zscore=2.2, price_zscore=2.0, range_position=0.95,
        trend_slope=0.001, atr_pct=0.01, reversal_return_1=-0.003,
        momentum_consistency=0.8, volume_ratio=2.0,
    )


def main() -> int:
    settings = yaml.safe_load((ROOT / "config/settings.yaml").read_text(encoding="utf-8")) or {}
    if not bool(settings.get("phase2_federation_enabled", False)):
        fail("Phase-2 federation is not enabled")
    configured = settings.get("phase2_federation_models") or []
    if len(configured) != 6 or len(set(configured)) != 6:
        fail("expected six unique configured federation models")
    for key, expected in {
        "dry_run": True,
        "live_mode": False,
        "phase0_quarantine": True,
        "public_bot_metrics_auto_promote": False,
    }.items():
        if settings.get(key) is not expected:
            fail(f"settings.yaml: {key} must be {expected}")

    cfg = SimpleNamespace(
        phase2_federation_enabled=True,
        phase2_federation_models=configured,
        phase2_federation_min_data_quality=0.99,
        phase2_federation_minimum_edge_multiple=1.25,
    )
    federation = ResearchModelFederation(cfg, ResearchCostModel())
    manifest = federation.manifest()
    if manifest.get("model_count") != 6:
        fail("federation did not instantiate six models")
    if manifest.get("external_execution_runtimes_started") != 0:
        fail("external execution runtime started")
    if manifest.get("private_api_wired") or manifest.get("execution_wired"):
        fail("federation reports execution wiring")
    if manifest.get("orders_submitted") != 0:
        fail("federation reports submitted orders")

    vector = strong_feature()
    for model in federation.models:
        rows = [model.forecast(vector, horizon_seconds=h) for h in (300, 900, 3600)]
        if any(row.execution_eligible for row in rows):
            fail(f"{model.model_id} emitted execution eligibility")
        if any((row.inputs.get("federation") or {}).get("authority") != "research_forecast_only" for row in rows):
            fail(f"{model.model_id} omitted research-only authority provenance")
        non_abstain = [row for row in rows if not row.abstain]
        if non_abstain and len({row.expected_move_bps for row in non_abstain}) == 1:
            fail(f"{model.model_id} cloned movement estimates across horizons")

    guard = PhoenixAuthorityGuard()
    for action in PROTECTED_ACTIONS:
        if guard.decision("research_model_federation", action).allowed:
            fail(f"research_model_federation unexpectedly allowed {action}")

    source = (ROOT / "strategies/volatility_breakout/research_model_federation.py").read_text(encoding="utf-8")
    forbidden_imports = ("import ccxt", "from ccxt", "from .kraken_canary", "import kraken_canary", "from agents.trade_executors", "import agents.trade_executors")
    for token in forbidden_imports:
        if token in source:
            fail(f"forbidden execution dependency in federation source: {token}")

    phase1_source = (ROOT / "scripts/run_phase1_observer.py").read_text(encoding="utf-8")
    if "research_model_federation" in phase1_source:
        fail("Phase 1 observer was contaminated with model execution")
    phase2_source = (ROOT / "strategies/volatility_breakout/hypothesis_competition.py").read_text(encoding="utf-8")
    if "ResearchModelFederation" not in phase2_source:
        fail("Phase 2 does not instantiate the federation")
    ui = (ROOT / "desktop-ui/renderer/index.html").read_text(encoding="utf-8")
    if "Live Research Federation" not in ui or "federation-model-tbody" not in ui:
        fail("research federation dashboard missing")

    print("PASS: Phase-7.2 live research model federation preflight")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

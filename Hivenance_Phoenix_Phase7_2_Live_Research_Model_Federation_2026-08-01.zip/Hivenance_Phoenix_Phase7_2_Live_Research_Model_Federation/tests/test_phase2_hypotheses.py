from __future__ import annotations

import time
from dataclasses import asdict, dataclass
from pathlib import Path

from agents.data_store_agent import DataStoreAgent
from strategies.volatility_breakout.cost_model import ResearchCostModel
from strategies.volatility_breakout.hypothesis_models import (
    BreakoutContinuationModel,
    ExhaustionMeanReversionModel,
)
from strategies.volatility_breakout.hypothesis_swarm import HypothesisSwarmAgent
from strategies.volatility_breakout.models import FeatureVector


@dataclass
class Phase2Config:
    exchange: str = "kraken"
    phase2_hypotheses_enabled: bool = True
    phase1_observation_interval_sec: int = 120
    phase2_horizons_seconds: tuple[int, ...] = (300, 900, 3600)
    phase2_min_data_quality: float = 0.99
    phase2_taker_fee_bps_per_side: float = 10.0
    phase2_reference_notional_usd: float = 5.0
    phase2_latency_buffer_bps: float = 2.0
    phase2_safety_buffer_bps: float = 3.0
    phase2_max_total_cost_bps: float = 150.0
    phase2_minimum_edge_multiple: float = 2.0
    phase2_breakout_min_expansion: float = 1.25
    phase2_breakout_min_volume_zscore: float = 0.50
    phase2_breakout_min_return_zscore: float = 0.75
    phase2_reversion_min_stretch_zscore: float = 1.50
    phase2_reversion_min_range_extreme: float = 0.85


def feature(**overrides) -> FeatureVector:
    values = dict(
        symbol="TEST/USD",
        timestamp_ms=int(time.time() * 1000),
        price=100.0,
        realized_volatility_fast=0.008,
        realized_volatility_baseline=0.004,
        volatility_expansion=2.0,
        volume_zscore=2.0,
        trade_count_zscore=None,
        order_flow_imbalance=None,
        book_imbalance=0.25,
        spread_bps=4.0,
        depth_usd_25bps=1_000_000.0,
        quote_volume_24h=100_000_000.0,
        return_5=0.012,
        freshness_sec=1.0,
        continuity_ratio=1.0,
        data_quality=1.0,
        values={"feature_version": "phase2.v1"},
        complete=True,
        return_zscore=2.2,
        price_zscore=2.0,
        range_position=0.95,
        trend_slope=0.001,
        atr_pct=0.01,
        reversal_return_1=0.003,
        momentum_consistency=0.8,
        volume_ratio=2.0,
    )
    values.update(overrides)
    return FeatureVector(**values)


def test_breakout_continuation_produces_cost_adjusted_forecast():
    model = BreakoutContinuationModel(ResearchCostModel())
    forecast = model.forecast(feature())
    assert forecast.abstain is False
    assert forecast.direction == "UP"
    assert forecast.expected_net_bps > 0
    assert forecast.expected_move_bps > forecast.expected_cost_bps
    assert forecast.execution_eligible is False
    assert forecast.calibration_state == "COLD_START_PROVISIONAL"


def test_mean_reversion_requires_exhaustion_confirmation():
    model = ExhaustionMeanReversionModel(ResearchCostModel())
    no_reversal = model.forecast(feature(reversal_return_1=0.004, book_imbalance=0.2))
    assert no_reversal.abstain is True
    assert "exhaustion_not_confirmed" in no_reversal.reasons

    confirmed = model.forecast(feature(reversal_return_1=-0.005, book_imbalance=-0.2))
    assert confirmed.abstain is False
    assert confirmed.direction == "DOWN"
    assert confirmed.execution_eligible is False


class StubObserver:
    def __init__(self, vector: FeatureVector) -> None:
        self.vector = vector
        self.orders = []

    def run_once(self):
        return {
            "phase": 1,
            "status": "HEALTHY",
            "dataset_hash": "observation-hash",
            "run": {
                "run_id": "obs-test",
                "venue": "kraken",
                "started_at_ms": self.vector.timestamp_ms,
                "completed_at_ms": self.vector.timestamp_ms,
            },
            "candidates": [
                {
                    "symbol": self.vector.symbol,
                    "venue": "kraken",
                    "timestamp_ms": self.vector.timestamp_ms,
                    "price": self.vector.price,
                    "values": {"feature_vector": asdict(self.vector)},
                }
            ],
        }


class StoreBridge:
    def __init__(self, store: DataStoreAgent) -> None:
        self.store = store
        self.events = []

    def share_data(self, key, event):
        self.events.append((key, event))
        self.store.handle_event(event)


def test_hypothesis_swarm_persists_competition_and_never_executes(tmp_path: Path):
    now_ms = int(time.time() * 1000)
    vector = feature(timestamp_ms=now_ms - 400_000)
    store = DataStoreAgent(str(tmp_path / "phase2.db"))
    bridge = StoreBridge(store)
    observer = StubObserver(vector)
    swarm = HypothesisSwarmAgent(Phase2Config(), observer, coordinator=bridge)

    payload = swarm.run_once()
    assert payload["mode"] == "hypothesis_research_only"
    assert payload["execution_wired"] is False
    assert payload["orders_submitted"] == 0
    assert len(payload["forecasts"]) == 36
    assert all(row["execution_eligible"] is False for row in payload["forecasts"])
    assert all(row["order_intent"] is None for row in payload["forecasts"])
    assert observer.orders == []

    future_ts = (vector.timestamp_ms + 310_000)
    store.handle_event({
        "buzz": {"type": "buzz.observation.snapshot", "source": "TEST", "ts": future_ts},
        "payload": {
            "status": "HEALTHY",
            "dataset_hash": "future-hash",
            "run": {
                "run_id": "obs-future",
                "started_at_ms": future_ts,
                "completed_at_ms": future_ts,
                "venue": "kraken",
                "symbols_attempted": 1,
                "symbols_successful": 1,
                "symbols_eligible": 1,
                "mean_data_quality": 1.0,
                "errors": [],
            },
            "candidates": [{
                "symbol": vector.symbol,
                "venue": "kraken",
                "timestamp_ms": future_ts,
                "price": 101.5,
                "data_quality": 1.0,
                "observation_eligible": True,
                "execution_eligible": False,
                "rejection_reasons": [],
                "values": {"volatility_expansion": 1.5},
            }],
        },
    })

    settlement = store.settle_mature_hypothesis_forecasts(now_ts=time.time(), tolerance_sec=120)
    assert settlement["settled"] == 12  # twelve research/baseline models at the five-minute horizon
    assert settlement["orders_submitted"] == 0
    outcomes = store.get_hypothesis_outcomes(limit=50)
    assert len(outcomes) == 12
    scorecard = store.get_hypothesis_scorecard()
    assert len(scorecard["models"]) == 12
    assert sum(1 for row in scorecard["models"] if row.get("model_role") == "FEDERATED") == 6
    assert {row.get("model_family") for row in scorecard["models"] if row.get("model_role") == "FEDERATED"} == {
        "freqtrade", "jesse", "freqai", "finrl_crypto", "macrohft", "webcryptoagent"
    }
    assert scorecard["execution_eligible"] is False

    readiness = store.get_phase2_readiness(min_forecasts=1, min_settled_non_abstain=1, min_distinct_days=1)
    assert readiness["execution_eligible"] is False
    assert readiness["orders_submitted"] == 0


def test_low_quality_features_force_both_primary_models_to_abstain():
    cost = ResearchCostModel()
    bad = feature(data_quality=0.5, complete=False)
    assert BreakoutContinuationModel(cost).forecast(bad).abstain is True
    assert ExhaustionMeanReversionModel(cost).forecast(bad).abstain is True

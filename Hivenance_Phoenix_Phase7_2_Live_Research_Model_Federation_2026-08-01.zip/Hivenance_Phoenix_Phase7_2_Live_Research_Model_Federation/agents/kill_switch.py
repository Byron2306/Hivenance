"""Kill Switch Agent - Safety & Risk Sentinel

Implements a deterministic rule engine, simple state machine (OK/THROTTLE/HALT),
rolling counters, hysteresis and publishes authoritative `buzz.kill.check` and
`buzz.kill.trigger` events via the coordinator.
"""
import logging
import threading
import time
from collections import deque
from datetime import datetime
from typing import Any, Dict, Optional


OK = "OK"
THROTTLE = "THROTTLE"
HALT = "HALT"


class KillSwitchAgent:
    def __init__(self, coordinator: Any = None, *,
                 daily_loss_throttle_pct: float = -0.015,
                 daily_loss_halt_pct: float = -0.03,
                 rejects_threshold_5m: int = 5,
                 slippage_threshold: float = 0.003,  # 0.3%
                 market_stale_sec: float = 10.0,
                 wallet_stale_sec: float = 20.0,
                 throttle_clear_sec: int = 600,
                 grace_sec: int = 120,
                 enforce_stale: bool = True,
                 equity_floor_usd: float = 25.0):
        self.coordinator = coordinator
        self.state = OK
        self.reason: Optional[str] = None
        self.last_transition_ts = time.time()
        self._start_ts = time.time()

        # thresholds
        self.daily_loss_throttle_pct = daily_loss_throttle_pct
        self.daily_loss_halt_pct = daily_loss_halt_pct
        self.rejects_threshold_5m = rejects_threshold_5m
        self.slippage_threshold = slippage_threshold
        self.market_stale_sec = market_stale_sec
        self.wallet_stale_sec = wallet_stale_sec
        self.throttle_clear_sec = throttle_clear_sec
        self.grace_sec = grace_sec
        self.enforce_stale = bool(enforce_stale)
        self.equity_floor_usd = float(equity_floor_usd or 0.0)

        # rolling windows / counters
        self._rejects = deque()      # timestamps of rejects
        self._slippages = deque()    # (ts, slippage)
        self._auth_failures = 0
        self._last_market_ts = 0.0
        self._last_wallet_ts = 0.0
        self._intent_timestamps = deque()

        self._lock = threading.Lock()
        self._last_emit_ts = 0.0

        # start background monitor for hysteresis and periodic evaluation
        self._running = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()

    # ------------------ event ingestion ------------------
    def handle_event(self, evt: Dict[str, Any]):
        """Handle incoming buzz events. Safe to call from coordinator when events are shared."""
        try:
            typ = evt.get('buzz', {}).get('type', '')
            payload = evt.get('payload', {}) or {}
            now = time.time()
            changed = False
            new_state = None
            reason = None
            with self._lock:
                prev = self.state
                if typ == 'buzz.trade.execution':
                    status = (payload.get('status') or '').upper()
                    if status in ('REJECTED', 'ERROR'):
                        # record a reject
                        self._rejects.append(now)
                    # record slippage if present
                    try:
                        s = float(payload.get('slippage_pct') or 0.0)
                        if s > 0:
                            self._slippages.append((now, s))
                    except Exception:
                        pass
                elif typ == 'buzz.analytics.snapshot':
                    # analytics may contain aggregated metrics; prefer those for daily pnl and slippage
                    m = payload.get('payload') if isinstance(payload, dict) and 'payload' in payload else payload
                    # if analytics reports rejects or slippage, we can seed counters
                    try:
                        if m.get('rejected'):
                            # approximate: add rejected to recent window
                            for _ in range(int(m.get('rejected'))):
                                self._rejects.append(now)
                        if m.get('avg_slippage_pct'):
                            self._slippages.append((now, float(m.get('avg_slippage_pct'))))
                    except Exception:
                        pass
                elif typ == 'buzz.wallet.balance':
                    # update last wallet timestamp
                    ts = payload.get('ts') or int(time.time()*1000)
                    self._last_wallet_ts = int(ts) / 1000.0
                elif typ == 'buzz.market.health' or typ == 'buzz.market.data' or typ == 'buzz.market.candle':
                    ts = evt.get('buzz', {}).get('ts') or int(time.time()*1000)
                    self._last_market_ts = int(ts) / 1000.0
                elif typ == 'buzz.exec.health' or typ == 'buzz.coordinator.health':
                    # authority-level failures
                    if payload.get('auth_failure'):
                        self._auth_failures += 1
                        # escalate immediately
                        self._set_state(HALT, reason='AUTH_FAILURE')
                elif typ == 'buzz.kill.trigger':
                    # external / manual trigger
                    action = payload.get('action')
                    if payload.get('risk_state') == HALT:
                        self._set_state(HALT, reason=payload.get('reason') or 'MANUAL_TRIGGER')
                elif typ == 'buzz.coordinator.decision':
                    # track intent timestamps to spot bursts
                    self._intent_timestamps.append(now)
                # clean old entries as we go
                self._cleanup_locked()
                if self.state != prev:
                    changed = True
                    new_state = self.state
                    reason = self.reason
        except Exception:
            logging.exception('KillSwitchAgent.handle_event failed')
            return

        # Emit outside the lock to avoid deadlocks with coordinator.share_data
        try:
            if changed:
                self._publish_state(reason_override=reason)
                if new_state == HALT:
                    self._publish_trigger(reason)
        except Exception:
            logging.exception('KillSwitchAgent handle_event emit failed')

    # ------------------ monitoring / rules ------------------
    def _cleanup_locked(self):
        now = time.time()
        # drop rejects older than 5 minutes
        cutoff = now - 300
        while self._rejects and self._rejects[0] < cutoff:
            self._rejects.popleft()
        # drop slippages older than 5 minutes
        while self._slippages and self._slippages[0][0] < cutoff:
            self._slippages.popleft()
        # drop intents older than 60s (for burst detection)
        intent_cut = now - 60
        while self._intent_timestamps and self._intent_timestamps[0] < intent_cut:
            self._intent_timestamps.popleft()

    def _monitor_loop(self):
        while self._running:
            try:
                publish_heartbeat = False
                changed = False
                new_state = None
                reason = None
                now = time.time()
                with self._lock:
                    prev = self.state
                    self._evaluate()
                    if self.state != prev:
                        changed = True
                        new_state = self.state
                        reason = self.reason
                    # periodic state heartbeat for audit visibility
                    if (now - self._last_emit_ts) >= 30:
                        publish_heartbeat = True
                        self._last_emit_ts = now
                # Emit outside the lock to avoid deadlocks with coordinator.share_data
                if changed:
                    self._publish_state(reason_override=reason)
                    if new_state == HALT:
                        self._publish_trigger(reason)
                elif publish_heartbeat:
                    self._publish_state()
                time.sleep(1)
            except Exception:
                logging.exception('KillSwitchAgent monitor loop failed')
                time.sleep(1)

    def _evaluate(self):
        """Evaluate rules and update state if needed. This function assumes _lock is held."""
        now = time.time()
        # Grace period after startup to allow agents to warm up and publish data.
        # During grace, skip evaluation if we're still in OK state.
        if self.state == OK and (now - self._start_ts) < max(0, float(self.grace_sec or 0)):
            return
        # Rule A: auth failures -> immediate HALT (already set in handle_event)

        # Rule B: reject spike
        rejects_5m = len(self._rejects)
        if rejects_5m >= self.rejects_threshold_5m:
            self._set_state(THROTTLE, reason='REJECT_SPIKE')
            return

        # Rule C: slippage spike (avg over window)
        sl_vals = [s for (_, s) in self._slippages]
        avg_slip = (sum(sl_vals) / len(sl_vals)) if sl_vals else 0.0
        if avg_slip >= self.slippage_threshold:
            self._set_state(THROTTLE, reason='SLIPPAGE_SPIKE')
            return

        # Rule D: market/wallet staleness
        # Skip staleness checks if the corresponding agent is not enabled.
        try:
            agents = getattr(self.coordinator, 'agents', {}) if self.coordinator else {}
            market_enabled = bool(agents.get('market_data'))
            wallet_enabled = bool(agents.get('wallet'))
        except Exception:
            market_enabled = True
            wallet_enabled = True

        if self.enforce_stale:
            if market_enabled and self._last_market_ts and (time.time() - self._last_market_ts) > self.market_stale_sec:
                self._set_state(THROTTLE, reason='MARKET_STALE')
                return
            if wallet_enabled and self._last_wallet_ts and (time.time() - self._last_wallet_ts) > self.wallet_stale_sec:
                # Degrade to THROTTLE instead of HALT to allow data recovery while staying safe.
                self._set_state(THROTTLE, reason='WALLET_STALE')
                return

        # Rule E: daily PnL thresholds (try to fetch from analytics snapshot in coordinator shared data)
        daily_pct = None
        equity_est = None
        trades_window = None
        filled_window = None
        try:
            if self.coordinator:
                metrics = self.coordinator.data_cache.get('buzz.analytics.snapshot') if hasattr(self.coordinator, 'data_cache') else None
                if isinstance(metrics, dict) and 'payload' in metrics:
                    payload = metrics.get('payload', {})
                    # payload may include equity change percent (optional). We'll check for realized PnL pct keys if present
                    daily_pct = payload.get('daily_pnl_pct') or payload.get('equity_change_pct')
                    equity_est = payload.get('equity_usd_est')
                    trades_window = payload.get('trades')
                    filled_window = payload.get('filled')
        except Exception:
            pass
        # If equity_est wasn't present in analytics, try wallet snapshot equity
        if equity_est is None:
            try:
                if self.coordinator and hasattr(self.coordinator, 'data_cache'):
                    wb = self.coordinator.data_cache.get('buzz.wallet.balance')
                    if isinstance(wb, dict):
                        payload = wb.get('payload') if isinstance(wb.get('payload'), dict) else wb
                        if isinstance(payload, dict):
                            equity_est = payload.get('equity_usd_est') or payload.get('equity_usd')
            except Exception:
                equity_est = None

        if daily_pct is not None:
            try:
                dp = float(daily_pct)
                # If no trades in the window, skip daily loss gating to avoid false halts.
                try:
                    trades_val = float(trades_window) if trades_window is not None else None
                except Exception:
                    trades_val = None
                try:
                    filled_val = float(filled_window) if filled_window is not None else None
                except Exception:
                    filled_val = None
                if (trades_val is not None and trades_val <= 0) and (filled_val is not None and filled_val <= 0):
                    dp = 0.0
                # If equity is tiny, skip daily loss gating to avoid noisy % swings.
                if equity_est is not None and self.equity_floor_usd and float(equity_est) < self.equity_floor_usd:
                    dp = 0.0
                if dp <= self.daily_loss_halt_pct:
                    self._set_state(HALT, reason='DAILY_LOSS_LIMIT')
                    return
                if dp <= self.daily_loss_throttle_pct:
                    self._set_state(THROTTLE, reason='LOSS_THROTTLE')
                    return
            except Exception:
                pass

        # If we're in THROTTLE, check hysteresis: require throttle_clear_sec of clean metrics to return to OK
        if self.state == THROTTLE:
            # if no recent triggers (rejects/slippage) and market/wallet fresh, and enough time has passed
            elapsed = now - self.last_transition_ts
            if rejects_5m == 0 and avg_slip < self.slippage_threshold and (time.time() - self._last_market_ts) < self.market_stale_sec and (time.time() - self._last_wallet_ts) < self.wallet_stale_sec and elapsed >= self.throttle_clear_sec:
                self._set_state(OK, reason='THROTTLE_CLEARED')
            return

        # Normal case: keep OK

    def _set_state(self, new_state: str, reason: Optional[str] = None):
        if new_state == self.state:
            return False
        prev = self.state
        self.state = new_state
        self.reason = reason
        self.last_transition_ts = time.time()
        logging.warning(f"KillSwitch state change: {prev} -> {new_state} ({reason})")
        return True

    def _publish_state(self, reason_override: Optional[str] = None):
        """Emit a periodic kill-switch state snapshot for audit/UI visibility."""
        try:
            # Snapshot under lock, but publish outside to avoid deadlocks.
            with self._lock:
                payload = {
                    'risk_state': self.state,
                    'reason': reason_override if reason_override is not None else self.reason,
                    'metrics': {
                        'rejects_5m': len(self._rejects),
                        'avg_slippage_pct': (sum([s for (_, s) in self._slippages]) / len(self._slippages)) if self._slippages else 0.0,
                    },
                }
            evt = {'buzz': {'type': 'buzz.kill.check', 'source': 'KILL_SWITCH', 'ts': int(time.time()*1000)}, 'payload': payload}
            if self.coordinator:
                self.coordinator.share_data('buzz.kill.check', evt)
        except Exception:
            logging.exception('Failed to publish buzz.kill.check')

    def _publish_trigger(self, reason: Optional[str] = None):
        """Emit a kill trigger event outside locks."""
        try:
            trig = {'buzz': {'type': 'buzz.kill.trigger', 'source': 'KILL_SWITCH', 'ts': int(time.time()*1000)}, 'payload': {'risk_state': HALT, 'reason': reason or 'HALT', 'action': 'CANCEL_ALL'}}
            if self.coordinator:
                self.coordinator.share_data('buzz.kill.trigger', trig)
        except Exception:
            logging.exception('Failed to publish buzz.kill.trigger')

    # ------------------ public helpers ------------------
    def get_state(self) -> Dict[str, Any]:
        with self._lock:
            return {'state': self.state, 'reason': self.reason, 'since': self.last_transition_ts}

    def safety_reset(self, reason: str = "UI_RESET") -> bool:
        """Clear rolling counters and return to OK state."""
        try:
            with self._lock:
                self._rejects.clear()
                self._slippages.clear()
                self._intent_timestamps.clear()
                self._auth_failures = 0
                self._last_market_ts = 0.0
                self._last_wallet_ts = 0.0
                if self.state != OK:
                    self._set_state(OK, reason=reason)
            self._publish_state(reason_override=reason)
            return True
        except Exception:
            return False

    # Backwards-compatible API used by older coordinator logic
    def check_kill_switch(self, metrics: Optional[Dict[str, Any]] = None):
        """Return (triggered, reason) for legacy callers."""
        with self._lock:
            return (self.state == HALT, self.reason)

    def alert(self, reason: Optional[str] = None):
        """Legacy alert hook; moves to HALT if not already halted."""
        try:
            self._set_state(HALT, reason=reason or 'ALERT')
        except Exception:
            logging.exception('KillSwitch alert failed')

    def manual_resume(self):
        """Manual override to resume from HALT back to OK. Use sparingly."""
        changed = False
        with self._lock:
            if self.state == HALT:
                changed = self._set_state(OK, reason='MANUAL_RESUME')
        if changed:
            self._publish_state(reason_override='MANUAL_RESUME')

    def stop(self):
        self._running = False
        try:
            self._thread.join(timeout=1)
        except Exception:
            pass

    # Backwards-compatible control methods
    def pause_swarm(self):
        """Legacy pause API: force HALT."""
        changed = False
        with self._lock:
            changed = self._set_state(HALT, reason='MANUAL_PAUSE')
        if changed:
            self._publish_state(reason_override='MANUAL_PAUSE')
            self._publish_trigger('MANUAL_PAUSE')

    def resume_swarm(self):
        """Legacy resume API: manual resume from HALT to OK."""
        self.manual_resume()

    def is_paused(self) -> bool:
        return self.state == HALT

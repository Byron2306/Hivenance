#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import sys
import time
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.phoenix_authority import PROTECTED_ACTIONS, PhoenixAuthorityGuard
from strategies.volatility_breakout.hypothesis_competition import HypothesisCompetition
from strategies.volatility_breakout.models import FeatureVector


def vector(index: int, regime: str, symbol: str) -> FeatureVector:
    sign = 1 if index % 2 == 0 else -1
    base = {
        "quiet": dict(expansion=0.75, volume_z=-0.4, ret_z=0.15 * sign, ret5=0.0004 * sign, book=0.02 * sign,
                      trend=0.00001 * sign, range_pos=0.52, reversal=0.0001 * sign, consistency=0.45, atr=0.0012,
                      spread=5.0, depth=700_000.0),
        "trend": dict(expansion=2.1, volume_z=1.8, ret_z=2.0 * sign, ret5=0.011 * sign, book=0.28 * sign,
                      trend=0.0009 * sign, range_pos=0.94 if sign > 0 else 0.06, reversal=-0.0025 * sign,
                      consistency=0.82, atr=0.009, spread=4.0, depth=1_200_000.0),
        "exhaustion": dict(expansion=1.6, volume_z=1.1, ret_z=2.6 * sign, ret5=0.014 * sign, book=-0.22 * sign,
                      trend=0.00055 * sign, range_pos=0.97 if sign > 0 else 0.03, reversal=-0.004 * sign,
                      consistency=0.68, atr=0.011, spread=6.0, depth=850_000.0),
        "hostile_liquidity": dict(expansion=2.4, volume_z=1.3, ret_z=1.8 * sign, ret5=0.012 * sign, book=0.35 * sign,
                      trend=0.0008 * sign, range_pos=0.92 if sign > 0 else 0.08, reversal=-0.003 * sign,
                      consistency=0.76, atr=0.012, spread=75.0, depth=3_000.0),
        "chop": dict(expansion=1.1, volume_z=0.2, ret_z=0.45 * sign, ret5=0.002 * sign, book=-0.04 * sign,
                      trend=-0.00002 * sign, range_pos=0.58 if sign > 0 else 0.42, reversal=-0.0004 * sign,
                      consistency=0.48, atr=0.003, spread=8.0, depth=450_000.0),
    }[regime]
    now = int(time.time() * 1000) + index * 120_000
    return FeatureVector(
        symbol=symbol, timestamp_ms=now, price=100.0 + index * 0.01,
        realized_volatility_fast=base["atr"] * 0.8,
        realized_volatility_baseline=max(0.0001, base["atr"] * 0.4),
        volatility_expansion=base["expansion"], volume_zscore=base["volume_z"],
        trade_count_zscore=None, order_flow_imbalance=None, book_imbalance=base["book"],
        spread_bps=base["spread"], depth_usd_25bps=base["depth"], quote_volume_24h=100_000_000.0,
        return_5=base["ret5"], freshness_sec=1.0, continuity_ratio=1.0, data_quality=1.0,
        values={"feature_version": "phase2.v1", "synthetic_regime": regime}, complete=True,
        return_zscore=base["ret_z"], price_zscore=base["ret_z"] * 0.8,
        range_position=base["range_pos"], trend_slope=base["trend"], atr_pct=base["atr"],
        reversal_return_1=base["reversal"], momentum_consistency=base["consistency"],
        volume_ratio=max(0.2, 1.0 + base["volume_z"] * 0.25),
    )


def main() -> int:
    cfg = SimpleNamespace(
        phase2_federation_enabled=True,
        phase2_federation_min_data_quality=0.99,
        phase2_federation_minimum_edge_multiple=1.25,
    )
    competition = HypothesisCompetition(cfg)
    symbols = ("BTC/USD", "ETH/USD", "SOL/USD", "ADA/USD", "XRP/USD")
    regimes = ("quiet", "trend", "exhaustion", "hostile_liquidity", "chop")
    horizons = (300, 900, 3600)
    stats = defaultdict(lambda: {"forecasts": 0, "actions": 0, "abstentions": 0, "up": 0, "down": 0, "moves": []})
    total = execution_violations = order_intents = 0
    regime_counts = defaultdict(int)

    for index in range(150):
        regime = regimes[index % len(regimes)]
        feature = vector(index, regime, symbols[index % len(symbols)])
        regime_counts[regime] += 1
        for forecast in competition.evaluate(feature, horizons):
            total += 1
            row = stats[forecast.model_id]
            row["forecasts"] += 1
            if forecast.abstain:
                row["abstentions"] += 1
            else:
                row["actions"] += 1
                row[forecast.direction.lower()] += 1
                if forecast.expected_move_bps is not None:
                    row["moves"].append(float(forecast.expected_move_bps))
            execution_violations += int(bool(forecast.execution_eligible))
            order_intents += int("order_intent" in (forecast.inputs or {}))

    guard = PhoenixAuthorityGuard()
    denied = 0
    unexpected = 0
    for _ in range(20):
        for model_id in competition.federated_ids:
            for action in PROTECTED_ACTIONS:
                decision = guard.decision("research_model_federation", action)
                denied += int(not decision.allowed)
                unexpected += int(decision.allowed)

    models = {}
    for model_id, row in sorted(stats.items()):
        moves = row.pop("moves")
        row["action_rate"] = round(row["actions"] / max(1, row["forecasts"]), 6)
        row["mean_expected_move_bps"] = round(sum(moves) / len(moves), 6) if moves else None
        row["distinct_expected_moves"] = len({round(value, 6) for value in moves})
        models[model_id] = row

    federated_stats = {model_id: models[model_id] for model_id in competition.federated_ids}
    federated_all_act = all(row["actions"] > 0 for row in federated_stats.values())
    federated_all_abstain = all(row["abstentions"] > 0 for row in federated_stats.values())
    report = {
        "phase": "7.2",
        "campaign": "synthetic_live_research_federation",
        "feature_vectors": 150,
        "symbols": list(symbols),
        "regimes": dict(regime_counts),
        "horizons_seconds": list(horizons),
        "model_count": len(competition.all_model_ids),
        "native_primary_models": list(competition.primary_ids),
        "federated_models": list(competition.federated_ids),
        "baseline_models": list(competition.baseline_ids),
        "forecasts": total,
        "federated_all_models_acted": federated_all_act,
        "federated_all_models_abstained": federated_all_abstain,
        "execution_eligibility_violations": execution_violations,
        "order_intents_found": order_intents,
        "protected_authority_requests_denied": denied,
        "protected_authority_requests_unexpectedly_allowed": unexpected,
        "external_execution_runtimes_started": 0,
        "private_api_wired": False,
        "real_orders_submitted": 0,
        "models": models,
        "pass": bool(
            total == 150 * len(horizons) * len(competition.all_model_ids)
            and federated_all_act
            and federated_all_abstain
            and execution_violations == 0
            and order_intents == 0
            and unexpected == 0
        ),
        "boundary": "Synthetic feature regimes validate engineering behavior only, not profitability.",
    }
    output = ROOT / "PHASE7_2_SYNTHETIC_FEDERATION_REPORT.json"
    output.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

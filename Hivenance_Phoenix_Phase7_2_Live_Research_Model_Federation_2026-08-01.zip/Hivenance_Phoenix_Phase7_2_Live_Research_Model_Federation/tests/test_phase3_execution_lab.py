from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

from agents.data_store_agent import DataStoreAgent
from strategies.volatility_breakout.execution_engine import DeterministicExecutionSimulator
from strategies.volatility_breakout.execution_lab import ExecutionLabAgent


@dataclass
class Phase3Config:
    phase3_execution_lab_enabled: bool = True
    phase3_interval_sec: int = 120
    phase3_max_forecasts_per_cycle: int = 50
    phase3_simulated_equity_usd: float = 1000.0
    phase3_risk_fraction: float = 0.0005
    phase3_sleeve_fraction: float = 0.02
    phase3_max_notional_usd: float = 25.0
    phase3_max_depth_participation: float = 0.01
    phase3_base_latency_ms: float = 180.0
    phase3_max_slippage_bps: float = 75.0
    phase3_min_data_quality: float = 0.99
    phase3_min_notional_usd: float = 5.0
    phase3_maker_fee_bps: float = 10.0
    phase3_taker_fee_bps: float = 20.0
    phase3_max_entry_spread_bps: float = 60.0
    phase3_readiness_min_completed: int = 1
    phase3_readiness_max_mean_2x_loss_bps: float = 500.0
    phase2_settlement_tolerance_sec: int = 600


def candidate(direction: str = "UP", forecast_id: str = "forecast-1") -> dict:
    now = time.time()
    return {
        "forecast_id": forecast_id,
        "forecast_ts": now - 600,
        "target_ts": now - 300,
        "settled_ts": now - 250,
        "venue": "kraken",
        "symbol": "ETH/USD",
        "model_id": "breakout_continuation_v1",
        "hypothesis": "breakout_continuation",
        "horizon_seconds": 300,
        "direction": direction,
        "entry_price": 100.0,
        "exit_price": 102.0 if direction == "UP" else 98.0,
        "probability_positive_net": 0.64,
        "expected_move_bps": 180.0,
        "expected_cost_bps": 25.0,
        "expected_net_bps": 155.0,
        "directional_return_bps": 200.0,
        "net_return_bps": 175.0,
        "forecast_payload": {
            "inputs": {"cost": {"spread_bps": 4.0}},
        },
        "entry_observation": {
            "symbol": "ETH/USD",
            "venue": "kraken",
            "timestamp_ms": int((now - 600) * 1000),
            "price": 100.0,
            "spread_bps": 4.0,
            "depth_usd_25bps": 500_000.0,
            "data_quality": 1.0,
            "values": {
                "feature_vector": {
                    "atr_pct": 0.01,
                    "realized_volatility_fast": 0.008,
                    "spread_bps": 4.0,
                    "depth_usd_25bps": 500_000.0,
                    "data_quality": 1.0,
                }
            },
        },
    }


def test_simulator_is_deterministic_and_never_live():
    sim = DeterministicExecutionSimulator(Phase3Config())
    source = candidate()
    first = sim.simulate(source, run_id="run-a", order_policy="market", scenario="normal")
    second = sim.simulate(source, run_id="run-a", order_policy="market", scenario="normal")
    assert first.to_dict() == second.to_dict()
    assert first.status == "COMPLETED"
    assert first.terminal_state in {"CLOSED", "RECONCILED"}
    assert len(first.fills) == 2
    assert first.execution_wired is False
    assert first.real_orders_submitted == 0
    assert first.intent.live_eligible is False
    assert first.costs.total_cost_bps > 0


def test_down_forecasts_remain_synthetic_in_spot_only_lab():
    sim = DeterministicExecutionSimulator(Phase3Config())
    result = sim.simulate(candidate(direction="DOWN"), run_id="run-b", order_policy="market", scenario="normal")
    assert result.status == "COMPLETED"
    assert result.spot_executable is False
    assert "synthetic" in str(result.diagnostics.get("spot_note", "")).lower()
    assert result.real_orders_submitted == 0


def test_stressed_passive_policy_can_expire_without_fake_fill():
    sim = DeterministicExecutionSimulator(Phase3Config())
    expired = None
    for index in range(200):
        result = sim.simulate(
            candidate(forecast_id=f"passive-{index}"),
            run_id="run-c",
            order_policy="passive_post_only",
            scenario="liquidity_stress",
        )
        if result.status == "EXPIRED":
            expired = result
            break
    assert expired is not None
    assert expired.fill_ratio == 0
    assert expired.fills == ()
    assert expired.costs.missed_fill_opportunity_bps >= 0


def test_simulation_persistence_is_idempotent_and_does_not_touch_live_orders(tmp_path: Path):
    store = DataStoreAgent(str(tmp_path / "phase3.db"))
    result = DeterministicExecutionSimulator(Phase3Config()).simulate(
        candidate(), run_id="run-d", order_policy="market", scenario="normal"
    ).to_dict()
    assert store.persist_execution_simulation(result) is True
    assert store.persist_execution_simulation(result) is True
    assert store.conn.execute("SELECT COUNT(*) FROM simulated_orders").fetchone()[0] == 1
    assert store.conn.execute("SELECT COUNT(*) FROM simulated_fills").fetchone()[0] == 2
    assert store.conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0] == 0
    scorecard = store.get_execution_scorecard()
    assert scorecard["real_orders_submitted"] == 0
    assert scorecard["execution_wiring_violations"] == 0
    assert len(scorecard["rows"]) == 1


class NoopHypothesis:
    def run_once(self):
        raise AssertionError("replay-only execution lab must not drive Phase 2")


def seed_settled_forecast(store: DataStoreAgent) -> None:
    now_ms = int(time.time() * 1000)
    entry_ms = now_ms - 400_000
    target_ms = entry_ms + 300_000
    store.handle_event({
        "buzz": {"type": "buzz.observation.snapshot", "source": "TEST", "ts": entry_ms},
        "payload": {
            "status": "HEALTHY",
            "dataset_hash": "entry-hash",
            "run": {
                "run_id": "obs-entry", "started_at_ms": entry_ms,
                "completed_at_ms": entry_ms, "venue": "kraken",
                "symbols_attempted": 1, "symbols_successful": 1,
                "symbols_eligible": 1, "mean_data_quality": 1.0, "errors": [],
            },
            "candidates": [{
                "symbol": "ETH/USD", "venue": "kraken", "timestamp_ms": entry_ms,
                "price": 100.0, "quote_volume_24h": 100_000_000.0,
                "spread_bps": 4.0, "depth_usd_25bps": 500_000.0,
                "data_quality": 1.0, "observation_eligible": True,
                "execution_eligible": False, "rejection_reasons": [],
                "values": {"feature_vector": {
                    "atr_pct": 0.01, "realized_volatility_fast": 0.008,
                    "spread_bps": 4.0, "depth_usd_25bps": 500_000.0,
                    "data_quality": 1.0,
                }},
            }],
        },
    })
    store.handle_event({
        "buzz": {"type": "buzz.hypothesis.snapshot", "source": "TEST", "ts": entry_ms},
        "payload": {
            "status": "HEALTHY", "dataset_hash": "hyp-hash",
            "run": {
                "run_id": "hyp-entry", "observation_run_id": "obs-entry",
                "started_at_ms": entry_ms, "completed_at_ms": entry_ms,
                "venue": "kraken", "symbols_evaluated": 1,
                "forecasts_total": 1, "non_abstain_forecasts": 1,
                "abstentions": 0,
            },
            "forecasts": [{
                "forecast_id": "settled-forecast", "run_id": "hyp-entry",
                "observation_run_id": "obs-entry", "timestamp_ms": entry_ms,
                "target_timestamp_ms": target_ms, "venue": "kraken",
                "symbol": "ETH/USD", "model_id": "breakout_continuation_v1",
                "hypothesis": "breakout_continuation", "horizon_seconds": 300,
                "direction": "UP", "entry_price": 100.0,
                "probability_positive_net": 0.65, "expected_move_bps": 180.0,
                "expected_cost_bps": 25.0, "expected_net_bps": 155.0,
                "raw_score": 0.7, "abstain": False, "reason": "test",
                "execution_eligible": False, "inputs": {},
            }],
        },
    })
    future_ms = target_ms + 1_000
    store.handle_event({
        "buzz": {"type": "buzz.observation.snapshot", "source": "TEST", "ts": future_ms},
        "payload": {
            "status": "HEALTHY", "dataset_hash": "future-hash",
            "run": {
                "run_id": "obs-future", "started_at_ms": future_ms,
                "completed_at_ms": future_ms, "venue": "kraken",
                "symbols_attempted": 1, "symbols_successful": 1,
                "symbols_eligible": 1, "mean_data_quality": 1.0, "errors": [],
            },
            "candidates": [{
                "symbol": "ETH/USD", "venue": "kraken", "timestamp_ms": future_ms,
                "price": 102.0, "quote_volume_24h": 100_000_000.0,
                "spread_bps": 4.0, "depth_usd_25bps": 500_000.0,
                "data_quality": 1.0, "observation_eligible": True,
                "execution_eligible": False, "rejection_reasons": [], "values": {},
            }],
        },
    })
    settled = store.settle_mature_hypothesis_forecasts(now_ts=time.time(), tolerance_sec=120)
    assert settled["settled"] == 1


def test_execution_lab_runs_policy_tournament_without_phase2_or_live_execution(tmp_path: Path):
    store = DataStoreAgent(str(tmp_path / "lab.db"))
    seed_settled_forecast(store)
    lab = ExecutionLabAgent(Phase3Config(), NoopHypothesis(), store)
    payload = lab.run_once(drive_phase2=False)
    assert payload["mode"] == "execution_simulation_only"
    assert payload["run"]["forecasts_examined"] == 1
    assert payload["run"]["simulations_created"] == 20
    assert payload["real_orders_submitted"] == 0
    assert store.conn.execute("SELECT COUNT(*) FROM simulated_orders").fetchone()[0] == 20
    assert store.conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0] == 0
    # Idempotent rerun creates no duplicate simulations.
    repeat = lab.run_once(drive_phase2=False)
    assert repeat["run"]["simulations_created"] == 0
    assert repeat["run"]["forecasts_examined"] == 0
    assert store.conn.execute("SELECT COUNT(*) FROM simulated_orders").fetchone()[0] == 20

# Hivenance Phoenix Phase 7.2 Operator Guide

## Purpose

Phase 7.2 strengthens the public research pipeline by adding six live research-only models to the Phase-2 truth-settled competition. Phase 1 remains a pure public-data observer. Phase 2 consumes the same immutable observation snapshots and evaluates all native, federated, and baseline models before any outcome is known.

No API key, funded account, private endpoint, wallet, or live execution process is required.

## Active model roster

### Phoenix native

- `breakout_continuation_v1`
- `exhaustion_mean_reversion_v1`

### Federated research models

- `adapter_freqtrade_breakout_v1`
- `adapter_jesse_trend_pullback_v1`
- `candidate_freqai_transparent_linear_v1`
- `candidate_finrl_conservative_policy_proxy_v1`
- `candidate_macrohft_regime_microstructure_proxy_v1`
- `candidate_webcrypto_market_context_proxy_v1`

### Baselines

- `baseline_no_trade_v1`
- `baseline_simple_momentum_v1`
- `baseline_simple_mean_reversion_v1`
- `baseline_deterministic_random_v1`

Each symbol therefore produces 36 forecasts per observation cycle: 12 models across 5m, 15m, and 60m horizons.

## Fidelity boundary

The new models are dependency-light internal adapters and transparent proxies:

- The Freqtrade and Jesse models implement deterministic strategy patterns inspired by those frameworks. They do not launch the upstream runtimes.
- The FreqAI candidate is a frozen transparent linear proxy. It does not train FreqAI models.
- The FinRL candidate is a frozen risk-adjusted policy proxy. It does not load an RL checkpoint or learn online.
- The MacroHFT candidate uses observation-book proxies. It does not claim sequence-accurate L2 replay.
- The WebCryptoAgent candidate uses market context only. It does not infer absent news, LLM, narrative, wallet-flow, or on-chain context.

Every row carries this provenance inside its forecast payload.

## Fresh installation

```bash
python3 -m venv .venv-phase72
source .venv-phase72/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-phase2.txt

for phase in 0 1 2 3 4 5 6 7; do
  python "scripts/phase${phase}_preflight.py" || exit 1
done
python scripts/phase7_1_preflight.py
python scripts/phase7_2_preflight.py
python -m pytest -q
```

Expected Phase-7.2 result:

```text
PASS: Phase-7.2 live research model federation preflight
58 passed
```

## Continue an existing observation database

Stop the old observer or Phase-2 runner cleanly before moving the database.

Create a SQLite-safe backup in the old project:

```bash
mkdir -p backups
sqlite3 data/swarm_data.db ".backup 'backups/swarm_data_pre_phase72.db'"
```

Copy the database into the new Phase-7.2 project:

```bash
mkdir -p data
cp /path/to/old/project/data/swarm_data.db data/swarm_data.db
```

The schema is backward-compatible. Existing observations, native forecasts, outcomes, simulations, and later-phase evidence remain intact. The new model IDs begin their own evidence histories from the first Phase-7.2 cycle. Historical rows are not rewritten.

Alternatively, point the runner directly at the existing database:

```bash
python scripts/run_phase7_2_federation.py \
  --database /absolute/path/to/swarm_data.db \
  --exchange kraken
```

Do not run the old and new Phase-2 processes against the same database simultaneously.

## One-cycle test

```bash
python scripts/run_phase7_2_federation.py \
  --exchange kraken \
  --once \
  --json
```

Confirm:

```text
federation.model_count = 6
external_execution_runtimes_started = 0
private_api_wired = false
execution_wired = false
orders_submitted = 0
```

## Continuous research operation

```bash
tmux new -s hivenance-federation
source .venv-phase72/bin/activate
python scripts/run_phase7_2_federation.py --exchange kraken
```

Detach with `Ctrl+B`, then `D`.

Reconnect with:

```bash
tmux attach -t hivenance-federation
```

The ordinary Phase-2 command remains equivalent:

```bash
python scripts/run_phase2_hypotheses.py --exchange kraken
```

## Research discipline

Do not change thresholds, coefficients, enabled model IDs, fee assumptions, or feature definitions during a running evidence window. A changed model must receive a new model ID and a new evidence window.

Do not interpret a high action rate as quality. The relevant evidence is settled after-cost performance, calibration, stability across days and symbols, and later Phase-3 and Phase-4 survival.

## Safety contract

The federation may:

- observe public market data
- emit timestamped forecasts
- abstain
- record transparent inputs and provenance
- receive later truth settlement
- enter Phase-3 simulation and Phase-4 validation

It may never:

- access private endpoints
- use exchange credentials
- construct a live order intent
- submit or transmit an order
- grant execution eligibility
- promote itself
- resume a halted live system
- scale capital
- retrain during a frozen campaign

Phase 6 remains the sole live-order authority. Phase 7 remains the sole scaling authority.

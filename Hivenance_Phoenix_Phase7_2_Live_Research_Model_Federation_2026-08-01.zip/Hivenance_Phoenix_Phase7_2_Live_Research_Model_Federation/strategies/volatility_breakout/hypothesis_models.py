from __future__ import annotations

import hashlib
import math
from dataclasses import asdict
from typing import Iterable, Protocol

from .cost_model import CostEstimate, ResearchCostModel
from .models import FeatureVector, Forecast


def _clip(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def _signed(value: float | None) -> int:
    if value is None or value == 0:
        return 0
    return 1 if value > 0 else -1


def _direction(sign: int) -> str:
    return "UP" if sign > 0 else "DOWN" if sign < 0 else "ABSTAIN"


def _probability(score: float, *, floor: float = 0.50, ceiling: float = 0.82) -> float:
    return round(floor + (ceiling - floor) * _clip(score), 6)


def _abstain(
    features: FeatureVector,
    model_id: str,
    hypothesis: str,
    horizon_seconds: int,
    reasons: Iterable[str],
    *,
    cost: CostEstimate | None = None,
    raw_score: float | None = None,
    inputs: dict | None = None,
) -> Forecast:
    reason_list = tuple(str(item) for item in reasons if item)
    return Forecast(
        symbol=features.symbol,
        timestamp_ms=features.timestamp_ms,
        horizon_seconds=horizon_seconds,
        model_id=model_id,
        hypothesis=hypothesis,
        direction="ABSTAIN",
        probability_positive_net=None,
        expected_move_bps=None,
        expected_cost_bps=cost.total_bps if cost else None,
        expected_net_bps=None,
        raw_score=raw_score,
        uncertainty=1.0,
        calibration_state="COLD_START",
        feature_version="phase2.v1",
        abstain=True,
        reason=reason_list[0] if reason_list else "abstain",
        reasons=reason_list,
        inputs=inputs or {},
        execution_eligible=False,
    )


class HypothesisModel(Protocol):
    model_id: str
    hypothesis: str
    is_baseline: bool

    def forecast(self, features: FeatureVector, *, horizon_seconds: int = 900) -> Forecast: ...


class BreakoutContinuationModel:
    model_id = "breakout_continuation_v1"
    hypothesis = "breakout_continuation"
    is_baseline = False

    def __init__(
        self,
        cost_model: ResearchCostModel,
        *,
        min_data_quality: float = 0.99,
        min_expansion: float = 1.25,
        min_volume_zscore: float = 0.50,
        min_return_zscore: float = 0.75,
        minimum_edge_multiple: float = 2.0,
    ) -> None:
        self.cost_model = cost_model
        self.min_data_quality = min_data_quality
        self.min_expansion = min_expansion
        self.min_volume_zscore = min_volume_zscore
        self.min_return_zscore = min_return_zscore
        self.minimum_edge_multiple = minimum_edge_multiple

    def forecast(self, features: FeatureVector, *, horizon_seconds: int = 900) -> Forecast:
        reasons: list[str] = []
        if not features.complete:
            reasons.append("features_incomplete")
        if features.data_quality < self.min_data_quality:
            reasons.append("data_quality_below_gate")
        if features.volatility_expansion is None or features.volatility_expansion < self.min_expansion:
            reasons.append("volatility_not_expanding")
        if features.volume_zscore is None or features.volume_zscore < self.min_volume_zscore:
            reasons.append("participation_not_confirmed")
        if features.return_zscore is None or abs(features.return_zscore) < self.min_return_zscore:
            reasons.append("directional_move_not_material")
        sign = _signed(features.return_5)
        if sign == 0:
            reasons.append("direction_unavailable")

        cost = self.cost_model.estimate(features)
        if not cost.tradable:
            reasons.append(cost.reason)
        inputs = {
            "volatility_expansion": features.volatility_expansion,
            "volume_zscore": features.volume_zscore,
            "return_zscore": features.return_zscore,
            "return_5": features.return_5,
            "book_imbalance": features.book_imbalance,
            "trend_slope": features.trend_slope,
            "momentum_consistency": features.momentum_consistency,
            "cost": asdict(cost),
        }
        if reasons:
            return _abstain(features, self.model_id, self.hypothesis, horizon_seconds, reasons, cost=cost, inputs=inputs)

        expansion_score = _clip((float(features.volatility_expansion) - 1.0) / 2.5)
        volume_score = _clip((float(features.volume_zscore) + 0.5) / 3.5)
        return_score = _clip(abs(float(features.return_zscore)) / 3.0)
        momentum_score = _clip(float(features.momentum_consistency or 0.5))
        trend_alignment = 0.5
        if features.trend_slope is not None:
            trend_alignment = 1.0 if features.trend_slope * sign > 0 else 0.0
        book_alignment = 0.5
        if features.book_imbalance is not None:
            book_alignment = _clip(0.5 + 0.5 * float(features.book_imbalance) * sign)

        score = (
            0.24 * expansion_score
            + 0.20 * volume_score
            + 0.24 * return_score
            + 0.14 * momentum_score
            + 0.10 * trend_alignment
            + 0.08 * book_alignment
        )
        atr_bps = max(1.0, float(features.atr_pct or features.realized_volatility_fast or 0.0) * 10_000.0)
        expected_move = atr_bps * (0.65 + 0.95 * score)
        expected_net = expected_move - cost.total_bps
        edge_multiple = expected_move / max(cost.total_bps, 0.000001)
        probability = _probability(score)
        if expected_net <= 0 or edge_multiple < self.minimum_edge_multiple:
            reasons = ["insufficient_cost_adjusted_edge"]
            return _abstain(
                features, self.model_id, self.hypothesis, horizon_seconds, reasons,
                cost=cost, raw_score=score, inputs={**inputs, "edge_multiple": edge_multiple},
            )

        return Forecast(
            symbol=features.symbol,
            timestamp_ms=features.timestamp_ms,
            horizon_seconds=horizon_seconds,
            model_id=self.model_id,
            hypothesis=self.hypothesis,
            direction=_direction(sign),
            probability_positive_net=probability,
            expected_move_bps=round(expected_move, 6),
            expected_cost_bps=cost.total_bps,
            expected_net_bps=round(expected_net, 6),
            raw_score=round(score, 6),
            uncertainty=round(1.0 - score, 6),
            calibration_state="COLD_START_PROVISIONAL",
            feature_version="phase2.v1",
            abstain=False,
            reason="breakout_hypothesis_passed",
            reasons=(),
            inputs={**inputs, "edge_multiple": round(edge_multiple, 6)},
            execution_eligible=False,
        )


class ExhaustionMeanReversionModel:
    model_id = "exhaustion_mean_reversion_v1"
    hypothesis = "exhaustion_mean_reversion"
    is_baseline = False

    def __init__(
        self,
        cost_model: ResearchCostModel,
        *,
        min_data_quality: float = 0.99,
        min_stretch_zscore: float = 1.50,
        min_range_extreme: float = 0.85,
        minimum_edge_multiple: float = 2.0,
    ) -> None:
        self.cost_model = cost_model
        self.min_data_quality = min_data_quality
        self.min_stretch_zscore = min_stretch_zscore
        self.min_range_extreme = min_range_extreme
        self.minimum_edge_multiple = minimum_edge_multiple

    def forecast(self, features: FeatureVector, *, horizon_seconds: int = 900) -> Forecast:
        reasons: list[str] = []
        if not features.complete:
            reasons.append("features_incomplete")
        if features.data_quality < self.min_data_quality:
            reasons.append("data_quality_below_gate")
        stretch = features.return_zscore if features.return_zscore is not None else features.price_zscore
        if stretch is None or abs(stretch) < self.min_stretch_zscore:
            reasons.append("stretch_not_extreme")
        if features.range_position is None:
            reasons.append("range_position_unavailable")
        elif not (features.range_position >= self.min_range_extreme or features.range_position <= 1.0 - self.min_range_extreme):
            reasons.append("price_not_at_range_extreme")

        stretch_sign = _signed(stretch)
        sign = -stretch_sign
        if sign == 0:
            reasons.append("reversion_direction_unavailable")

        # Require a first sign of exhaustion rather than blindly fading strength.
        reversal_confirmed = False
        if features.reversal_return_1 is not None and stretch_sign:
            reversal_confirmed = features.reversal_return_1 * stretch_sign < 0
        if features.book_imbalance is not None and stretch_sign:
            reversal_confirmed = reversal_confirmed or features.book_imbalance * stretch_sign < -0.05
        if not reversal_confirmed:
            reasons.append("exhaustion_not_confirmed")

        cost = self.cost_model.estimate(features)
        if not cost.tradable:
            reasons.append(cost.reason)
        inputs = {
            "stretch_zscore": stretch,
            "return_zscore": features.return_zscore,
            "price_zscore": features.price_zscore,
            "range_position": features.range_position,
            "reversal_return_1": features.reversal_return_1,
            "book_imbalance": features.book_imbalance,
            "volatility_expansion": features.volatility_expansion,
            "cost": asdict(cost),
        }
        if reasons:
            return _abstain(features, self.model_id, self.hypothesis, horizon_seconds, reasons, cost=cost, inputs=inputs)

        stretch_score = _clip((abs(float(stretch)) - 1.0) / 3.0)
        extreme_score = _clip(abs(float(features.range_position) - 0.5) * 2.0)
        reversal_score = 0.5
        if features.reversal_return_1 is not None:
            reversal_score = _clip(abs(float(features.reversal_return_1)) * 10_000.0 / 30.0)
        book_score = 0.5
        if features.book_imbalance is not None:
            book_score = _clip(0.5 + 0.5 * float(features.book_imbalance) * sign)
        expansion_score = _clip((float(features.volatility_expansion or 1.0) - 0.8) / 2.5)
        score = (
            0.34 * stretch_score
            + 0.24 * extreme_score
            + 0.20 * reversal_score
            + 0.12 * book_score
            + 0.10 * expansion_score
        )
        atr_bps = max(1.0, float(features.atr_pct or features.realized_volatility_fast or 0.0) * 10_000.0)
        expected_move = atr_bps * (0.55 + 0.85 * score)
        expected_net = expected_move - cost.total_bps
        edge_multiple = expected_move / max(cost.total_bps, 0.000001)
        probability = _probability(score, floor=0.50, ceiling=0.78)
        if expected_net <= 0 or edge_multiple < self.minimum_edge_multiple:
            return _abstain(
                features, self.model_id, self.hypothesis, horizon_seconds,
                ["insufficient_cost_adjusted_edge"], cost=cost, raw_score=score,
                inputs={**inputs, "edge_multiple": edge_multiple},
            )

        return Forecast(
            symbol=features.symbol,
            timestamp_ms=features.timestamp_ms,
            horizon_seconds=horizon_seconds,
            model_id=self.model_id,
            hypothesis=self.hypothesis,
            direction=_direction(sign),
            probability_positive_net=probability,
            expected_move_bps=round(expected_move, 6),
            expected_cost_bps=cost.total_bps,
            expected_net_bps=round(expected_net, 6),
            raw_score=round(score, 6),
            uncertainty=round(1.0 - score, 6),
            calibration_state="COLD_START_PROVISIONAL",
            feature_version="phase2.v1",
            abstain=False,
            reason="mean_reversion_hypothesis_passed",
            reasons=(),
            inputs={**inputs, "edge_multiple": round(edge_multiple, 6)},
            execution_eligible=False,
        )


class NoTradeBaseline:
    model_id = "baseline_no_trade_v1"
    hypothesis = "baseline_no_trade"
    is_baseline = True

    def forecast(self, features: FeatureVector, *, horizon_seconds: int = 900) -> Forecast:
        return _abstain(features, self.model_id, self.hypothesis, horizon_seconds, ["baseline_no_trade"])


class SimpleMomentumBaseline:
    model_id = "baseline_simple_momentum_v1"
    hypothesis = "baseline_simple_momentum"
    is_baseline = True

    def __init__(self, cost_model: ResearchCostModel) -> None:
        self.cost_model = cost_model

    def forecast(self, features: FeatureVector, *, horizon_seconds: int = 900) -> Forecast:
        sign = _signed(features.return_5)
        cost = self.cost_model.estimate(features)
        if not features.complete or sign == 0 or not cost.tradable:
            return _abstain(features, self.model_id, self.hypothesis, horizon_seconds, ["baseline_unavailable"], cost=cost)
        move = abs(float(features.return_5 or 0.0)) * 10_000.0
        return Forecast(
            symbol=features.symbol, timestamp_ms=features.timestamp_ms, horizon_seconds=horizon_seconds,
            model_id=self.model_id, hypothesis=self.hypothesis, direction=_direction(sign),
            probability_positive_net=0.55, expected_move_bps=round(move, 6),
            expected_cost_bps=cost.total_bps, expected_net_bps=round(move - cost.total_bps, 6),
            raw_score=0.5, uncertainty=0.5, calibration_state="BASELINE_FIXED",
            feature_version="phase2.v1", abstain=False, reason="baseline_momentum",
            inputs={"return_5": features.return_5}, execution_eligible=False,
        )


class SimpleMeanReversionBaseline:
    model_id = "baseline_simple_mean_reversion_v1"
    hypothesis = "baseline_simple_mean_reversion"
    is_baseline = True

    def __init__(self, cost_model: ResearchCostModel) -> None:
        self.cost_model = cost_model

    def forecast(self, features: FeatureVector, *, horizon_seconds: int = 900) -> Forecast:
        stretch = features.return_zscore
        sign = -_signed(stretch)
        cost = self.cost_model.estimate(features)
        if not features.complete or stretch is None or abs(stretch) < 1.0 or sign == 0 or not cost.tradable:
            return _abstain(features, self.model_id, self.hypothesis, horizon_seconds, ["baseline_unavailable"], cost=cost)
        move = max(0.0, float(features.atr_pct or 0.0) * 10_000.0)
        return Forecast(
            symbol=features.symbol, timestamp_ms=features.timestamp_ms, horizon_seconds=horizon_seconds,
            model_id=self.model_id, hypothesis=self.hypothesis, direction=_direction(sign),
            probability_positive_net=0.55, expected_move_bps=round(move, 6),
            expected_cost_bps=cost.total_bps, expected_net_bps=round(move - cost.total_bps, 6),
            raw_score=0.5, uncertainty=0.5, calibration_state="BASELINE_FIXED",
            feature_version="phase2.v1", abstain=False, reason="baseline_mean_reversion",
            inputs={"return_zscore": stretch}, execution_eligible=False,
        )


class DeterministicRandomBaseline:
    model_id = "baseline_deterministic_random_v1"
    hypothesis = "baseline_random"
    is_baseline = True

    def __init__(self, cost_model: ResearchCostModel) -> None:
        self.cost_model = cost_model

    def forecast(self, features: FeatureVector, *, horizon_seconds: int = 900) -> Forecast:
        cost = self.cost_model.estimate(features)
        if not features.complete or not cost.tradable:
            return _abstain(features, self.model_id, self.hypothesis, horizon_seconds, ["baseline_unavailable"], cost=cost)
        digest = hashlib.sha256(f"{features.symbol}:{features.timestamp_ms}:{horizon_seconds}".encode()).digest()
        sign = 1 if digest[0] % 2 == 0 else -1
        return Forecast(
            symbol=features.symbol, timestamp_ms=features.timestamp_ms, horizon_seconds=horizon_seconds,
            model_id=self.model_id, hypothesis=self.hypothesis, direction=_direction(sign),
            probability_positive_net=0.50, expected_move_bps=0.0, expected_cost_bps=cost.total_bps,
            expected_net_bps=-cost.total_bps, raw_score=0.0, uncertainty=1.0,
            calibration_state="BASELINE_FIXED", feature_version="phase2.v1", abstain=False,
            reason="baseline_deterministic_random", inputs={}, execution_eligible=False,
        )

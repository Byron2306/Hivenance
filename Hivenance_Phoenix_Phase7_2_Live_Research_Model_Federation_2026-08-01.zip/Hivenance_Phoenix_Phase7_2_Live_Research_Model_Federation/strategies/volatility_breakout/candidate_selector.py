from __future__ import annotations

from dataclasses import replace
from typing import Iterable

from .models import CandidateObservation


class ObservationOnlyCandidateSelector:
    """Ranks assets for research observation while permanently denying execution."""

    def __init__(
        self,
        *,
        min_listing_age_days: float = 90,
        min_depth_usd_25bps: float = 25_000,
        min_quote_volume_24h_usd: float = 5_000_000,
        max_spread_bps: float = 35,
        min_data_quality: float = 0.99,
    ) -> None:
        self.min_listing_age_days = max(0.0, float(min_listing_age_days))
        self.min_depth_usd_25bps = max(0.0, float(min_depth_usd_25bps))
        self.min_quote_volume_24h_usd = max(0.0, float(min_quote_volume_24h_usd))
        self.max_spread_bps = max(0.0, float(max_spread_bps))
        self.min_data_quality = max(0.0, min(1.0, float(min_data_quality)))

    def evaluate(self, observation: CandidateObservation) -> CandidateObservation:
        reasons: list[str] = []
        if observation.listing_age_days is not None and observation.listing_age_days < self.min_listing_age_days:
            reasons.append('listing_too_new')
        if (observation.quote_volume_24h or 0.0) < self.min_quote_volume_24h_usd:
            reasons.append('insufficient_quote_volume')
        if (observation.depth_usd_25bps or 0.0) < self.min_depth_usd_25bps:
            reasons.append('insufficient_executable_depth')
        if observation.spread_bps is None:
            reasons.append('spread_unavailable')
        elif observation.spread_bps > self.max_spread_bps:
            reasons.append('spread_too_wide')
        if observation.data_quality < self.min_data_quality:
            reasons.append('data_quality_below_phase1_gate')
        if observation.freshness_sec is None:
            reasons.append('freshness_unavailable')
        if observation.continuity_ratio is None or observation.continuity_ratio < 0.95:
            reasons.append('candle_continuity_below_gate')

        observation_eligible = not reasons
        volume_score = min(1.0, (observation.quote_volume_24h or 0.0) / max(1.0, self.min_quote_volume_24h_usd * 10.0))
        depth_score = min(1.0, (observation.depth_usd_25bps or 0.0) / max(1.0, self.min_depth_usd_25bps * 10.0))
        spread_score = 0.0 if observation.spread_bps is None else max(0.0, 1.0 - observation.spread_bps / max(1.0, self.max_spread_bps))
        expansion = float(observation.values.get('volatility_expansion') or 0.0)
        expansion_score = min(1.0, expansion / 3.0)
        score = (
            0.35 * observation.data_quality
            + 0.20 * volume_score
            + 0.15 * depth_score
            + 0.15 * spread_score
            + 0.15 * expansion_score
        )
        return replace(
            observation,
            score=round(max(0.0, min(1.0, score)), 6),
            eligible=observation_eligible,
            observation_eligible=observation_eligible,
            execution_eligible=False,
            rejection_reasons=tuple(reasons),
        )

    def rank(self, observations: Iterable[CandidateObservation]) -> list[CandidateObservation]:
        evaluated = [self.evaluate(item) for item in observations]
        return sorted(
            evaluated,
            key=lambda item: (
                not item.observation_eligible,
                -item.score,
                item.spread_bps if item.spread_bps is not None else float('inf'),
                -(item.depth_usd_25bps or 0.0),
            ),
        )
